# MyLauncher
Build: open in Android Studio and run Build > Build APK(s), or `gradle assembleDebug`.
Output: app/build/outputs/apk/debug/app-debug.apk
Or push to GitHub: the included Action builds the APK for you.
After installing, press Home and choose "My Launcher" > Always.
