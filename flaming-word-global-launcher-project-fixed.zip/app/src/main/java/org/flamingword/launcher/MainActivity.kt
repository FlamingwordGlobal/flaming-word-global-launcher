package org.flamingword.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val purple = Color.rgb(54, 28, 91)
    private val gold = Color.rgb(218, 177, 83)
    private val cream = Color.rgb(250, 247, 241)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = purple
        window.navigationBarColor = Color.BLACK
        showHome()
    }

    private fun background(color: Int, radius: Float = 22f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun showHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 16)
            setBackgroundColor(cream)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            background = background(purple, 28f)
        }
        header.addView(text("FLAMING WORD", 13f, gold, true))
        header.addView(text("GLOBAL LAUNCHER", 25f, Color.WHITE, true).apply {
            setPadding(0, 5, 0, 5)
        })
        header.addView(text("BE IGNITED BY THE WORD TO INVADE DARKNESS", 10f, Color.WHITE))
        header.addView(text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), 13f, gold).apply {
            setPadding(0, 18, 0, 0)
        })
        content.addView(header)

        content.addView(text("Welcome home", 22f, purple, true).apply {
            setPadding(2, 24, 0, 12)
        })

        val verse = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            background = background(Color.WHITE, 20f)
        }
        verse.addView(text("TODAY'S WORD", 11f, gold, true))
        verse.addView(text("“Arise, shine; for thy light is come.”", 18f, purple, true).apply {
            setPadding(0, 9, 0, 5)
        })
        verse.addView(text("Isaiah 60:1  •  Let the Word ignite your day.", 12f, Color.DKGRAY))
        content.addView(verse)

        content.addView(text("Ministry access", 18f, purple, true).apply {
            setPadding(2, 24, 0, 12)
        })
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        addRow(grid,
            tile("📖", "Bible", "Open Bible", purple) { openWeb("https://www.bible.com") },
            tile("🎙", "Sermons", "Teaching library", purple) { openWeb("https://www.youtube.com") })
        addRow(grid,
            tile("🙏", "Prayer", "Prayer life", purple) { info("Prayer", "Create a place of prayer. Add your prayer requests and testimonies here in a future update.") },
            tile("📅", "Events", "Services & meetings", purple) { info("Ministry events", "Church events and announcements will appear here.") })
        addRow(grid,
            tile("🌍", "Our branches", "Zimbabwe • Malawi • Mozambique", purple) { info("Flaming Word branches", "Branch directory will be added with verified branch contacts and locations.") },
            tile("📢", "Announcements", "Ministry updates", purple) { info("Announcements", "Ministry news and announcements will appear here.") })
        content.addView(grid)

        val appsButton = Button(this).apply {
            text = "VIEW ALL PHONE APPS"
            setTextColor(Color.WHITE)
            setBackgroundColor(purple)
            setOnClickListener { showAppDrawer() }
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 54)
        params.topMargin = 22
        content.addView(appsButton, params)

        content.addView(text("Flaming Word International Ministries", 11f, Color.GRAY).apply {
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 4)
        })
        content.addView(text("Isaiah 60:1–3", 11f, gold, true).apply {
            gravity = Gravity.CENTER
        })

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun addRow(parent: LinearLayout, first: View, second: View) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(0, 0, 8, 8)
        row.addView(first, lp)
        val lp2 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp2.setMargins(8, 0, 0, 8)
        row.addView(second, lp2)
        parent.addView(row)
    }

    private fun tile(icon: String, title: String, subtitle: String, accent: Int, action: () -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 17, 12, 17)
            background = background(Color.WHITE, 18f)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
            addView(text(icon, 25f, accent))
            addView(text(title, 15f, accent, true).apply { setPadding(0, 7, 0, 3) })
            addView(text(subtitle, 10f, Color.DKGRAY))
        }
    }

    private fun showAppDrawer() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        val labels = apps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Your apps")
            .setItems(labels) { _, which ->
                val launch = pm.getLaunchIntentForPackage(apps[which].packageName)
                if (launch != null) startActivity(launch)
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun openWeb(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "No browser found", Toast.LENGTH_SHORT).show() }
    }

    private fun info(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setPositiveButton("OK", null).show()
    }
}
